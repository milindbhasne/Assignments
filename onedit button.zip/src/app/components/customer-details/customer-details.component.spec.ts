import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDetailsComponent } from './customer-details.component';

describe('CustomerDetailsComponent', () => {
  let component: CustomerDetailsComponent;
  let fixture: ComponentFixture<CustomerDetailsComponent>;
console.log("one")
  beforeEach(async(() => {
    console.log("two")
    TestBed.configureTestingModule({
      
      declarations: [ CustomerDetailsComponent ]
    })
    .compileComponents().then(result=>{
      fixture = TestBed.createComponent(CustomerDetailsComponent);
      console.log("after two")
      component = fixture.componentInstance;
      fixture.detectChanges();
      console.log("three");
      console.log("result"+result)
      
    })
   
  }));

 

  it('should create', () => {
    console.log("five")
    expect(component).toBeTruthy();
  });
});
