export class Customer {
  position: Number
   firstName: String
   DOB: String
   lastName: String
   Address:String
   country:String
   email:String
   city:String
   Mobileno:Number
}