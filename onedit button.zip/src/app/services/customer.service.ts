import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Customer } from "./customer.model";
import { FormGroup, FormControl, Validators } from "@angular/forms";

@Injectable()
export class CustomerService {
  url: string;
  header: any;
  readonly baseURL = "https://localhost:5001/CustomerInfo/customer";
  readonly baseURL1 = "http://localhost:3000/AddCustomer"
   dummyData : Customer[] =  [
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
    {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
    {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  ];
  
  constructor() {
    // const headerSettings: { [name: string]: string | string[] } = {};
    // this.header = new HttpHeaders(headerSettings);
  }

  form: FormGroup = new FormGroup({
  
    firstName: new FormControl("", Validators.required),
    lastName: new FormControl("", Validators.required),
    email: new FormControl("", Validators.email),
    Mobileno: new FormControl("", [Validators.required, Validators.minLength(8)]),
    Address: new FormControl(""),
    DOB: new FormControl(""),
   city: new FormControl("", Validators.required),
    //state: new FormControl("", Validators.required),
    country: new FormControl("", Validators.required),
    position: new FormControl("")
  });

  // Address: "301 jati colony ran bang "
  // DOB: "11-3-2019"
  // Mobileno: 895930564
  // city: "indore "
  // country: "india"
  // email: "milind.kumar@gmail.com"
  // firstName: "Hydrogen"
  // lastName: "H"
  // position: 1
    

  initializeFormGroup() {
  
    this.form.setValue({
     
      firstName: "",
      lastName: "",
      email: "",
      Mobileno: "",
      Address: "",
      DOB: "",
      city: "",
      position: "",
      country: ""
    });
  }

  //post request to add new customer

  postCustomer(details: Customer) {
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
   // return this.http.post<Customer[]>(this.baseURL, details, options);
  }

  //Get Request to get customer list

  getCustomerList() {
    return (this.dummyData);
  }

  populateForm(employee) {
    let fname = employee.firstName;
    
    this.form.patchValue(employee);
    console.log(this.form.controls.firstName)
  
  }

  // //Put api for details updation
  // updateCustomer() {
  //   const options = {
  //   headers: new HttpHeaders({ "content-type": "application/json" })
  //   };
  //   const bodyData = {
  //     //
  //     //
  //     //
  //   };
  //   return this.http.put(this.baseURL + `/`, bodyData, options);
  // }

  // //Delete api for remove Customer from list
  // removeCustomer(email: string) {
  //   return this.http.delete(this.baseURL + `/${email}`);
  // }
}
